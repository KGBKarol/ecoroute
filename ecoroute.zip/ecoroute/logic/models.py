# logic/models.py — Entidades del dominio

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum


class EstadoVehiculo(str, Enum):
    DISPONIBLE   = "disponible"
    EN_RUTA      = "en_ruta"
    CARGANDO     = "cargando"
    MANTENIMIENTO = "mantenimiento"


@dataclass
class Vehiculo:
    id_vehiculo: str
    modelo: str
    capacidad_bateria_total: float   # kWh
    nivel_bateria_actual: float      # 0–100 %
    autonomia_maxima_km: int
    estado: EstadoVehiculo

    @classmethod
    def from_dict(cls, d: dict) -> "Vehiculo":
        return cls(
            id_vehiculo=d["id_vehiculo"],
            modelo=d["modelo"],
            capacidad_bateria_total=float(d["capacidad_bateria_total"]),
            nivel_bateria_actual=float(d["nivel_bateria_actual"]),
            autonomia_maxima_km=int(d["autonomia_maxima_km"]),
            estado=EstadoVehiculo(d["estado"]),
        )

    def to_dict(self) -> dict:
        return {
            "id_vehiculo": self.id_vehiculo,
            "modelo": self.modelo,
            "capacidad_bateria_total": self.capacidad_bateria_total,
            "nivel_bateria_actual": self.nivel_bateria_actual,
            "autonomia_maxima_km": self.autonomia_maxima_km,
            "estado": self.estado.value,
        }

    # Capacity in km based on current battery level
    def autonomia_actual_km(self) -> float:
        return self.autonomia_maxima_km * (self.nivel_bateria_actual / 100)


@dataclass
class Entrega:
    id_entrega: str
    latitud: float
    longitud: float
    peso_kg: float
    prioridad: int       # 1–3
    ventana_horaria: str # "HH:MM - HH:MM"

    @classmethod
    def from_dict(cls, d: dict) -> "Entrega":
        return cls(
            id_entrega=d["id_entrega"],
            latitud=float(d["latitud"]),
            longitud=float(d["longitud"]),
            peso_kg=float(d["peso_kg"]),
            prioridad=int(d["prioridad"]),
            ventana_horaria=d["ventana_horaria"],
        )

    def to_dict(self) -> dict:
        return {
            "id_entrega": self.id_entrega,
            "latitud": self.latitud,
            "longitud": self.longitud,
            "peso_kg": self.peso_kg,
            "prioridad": self.prioridad,
            "ventana_horaria": self.ventana_horaria,
        }


@dataclass
class Ruta:
    id_ruta: str
    id_vehiculo: str
    lista_entregas: list[str] = field(default_factory=list)  # ordered IDs
    distancia_total_estimada: float = 0.0   # km
    consumo_estimado_bateria: float = 0.0   # % to subtract

    @classmethod
    def from_dict(cls, d: dict, entregas: list[str] | None = None) -> "Ruta":
        return cls(
            id_ruta=d["id_ruta"],
            id_vehiculo=d["id_vehiculo"],
            lista_entregas=entregas or [],
            distancia_total_estimada=float(d["distancia_total_estimada"]),
            consumo_estimado_bateria=float(d["consumo_estimado_bateria"]),
        )

    def to_dict(self) -> dict:
        return {
            "id_ruta": self.id_ruta,
            "id_vehiculo": self.id_vehiculo,
            "lista_entregas": self.lista_entregas,
            "distancia_total_estimada": self.distancia_total_estimada,
            "consumo_estimado_bateria": self.consumo_estimado_bateria,
        }
