# logic/services.py — Orquestador de casos de uso
# Único punto de contacto entre CLI y repositorio.

from __future__ import annotations
import math
from logic.models import Vehiculo, Entrega, Ruta
from logic import validators as v
from db.contact_repo import EcorouteRepository
from exceptions import NotFoundError, InsufficientBatteryError, OverweightError

# Límite de seguridad: si la ruta consume más del 80 % de la batería actual → rechazar
BATTERY_SAFETY_LIMIT = 80.0

# Consumo estimado: kWh por km (valor por defecto simplificado)
KWH_PER_KM = 0.2


class EcorouteService:

    def __init__(self, repo: EcorouteRepository):
        self._repo = repo

    # ==================================================================
    # VEHICULOS
    # ==================================================================

    def registrar_vehiculo(self, data: dict) -> Vehiculo:
        """CU-01: Validate and insert a new vehicle."""
        v.validate_id_vehiculo(data["id_vehiculo"])
        v.validate_modelo(data["modelo"])
        v.validate_capacidad_bateria(float(data["capacidad_bateria_total"]))
        v.validate_nivel_bateria(float(data["nivel_bateria_actual"]))
        v.validate_autonomia(int(data["autonomia_maxima_km"]))
        v.validate_estado(data["estado"])

        vehiculo = Vehiculo.from_dict(data)
        self._repo.insert_vehiculo(vehiculo.to_dict())
        return vehiculo

    def eliminar_vehiculo(self, id_vehiculo: str) -> None:
        """CU-02: Soft-delete a vehicle."""
        self._ensure_vehiculo_exists(id_vehiculo)
        self._repo.soft_delete_vehiculo(id_vehiculo)

    def obtener_vehiculo(self, id_vehiculo: str) -> Vehiculo:
        """CU-03: Return a single vehicle by ID."""
        return self._ensure_vehiculo_exists(id_vehiculo)

    def listar_vehiculos(self, pagina: int = 1, por_pagina: int = 20) -> tuple[list[Vehiculo], int]:
        """CU-04: Paginated vehicle list. Returns (vehicles, total_count)."""
        offset = (pagina - 1) * por_pagina
        rows = self._repo.get_all_vehiculos(limit=por_pagina, offset=offset)
        total = self._repo.count_vehiculos()
        return [Vehiculo.from_dict(r) for r in rows], total

    def editar_vehiculo(self, id_vehiculo: str, cambios: dict) -> Vehiculo:
        """CU-05: Validate and apply partial updates to a vehicle."""
        self._ensure_vehiculo_exists(id_vehiculo)
        validated = {}
        if "modelo" in cambios:
            v.validate_modelo(cambios["modelo"])
            validated["modelo"] = cambios["modelo"]
        if "capacidad_bateria_total" in cambios:
            v.validate_capacidad_bateria(float(cambios["capacidad_bateria_total"]))
            validated["capacidad_bateria_total"] = float(cambios["capacidad_bateria_total"])
        if "nivel_bateria_actual" in cambios:
            v.validate_nivel_bateria(float(cambios["nivel_bateria_actual"]))
            validated["nivel_bateria_actual"] = float(cambios["nivel_bateria_actual"])
        if "autonomia_maxima_km" in cambios:
            v.validate_autonomia(int(cambios["autonomia_maxima_km"]))
            validated["autonomia_maxima_km"] = int(cambios["autonomia_maxima_km"])
        if "estado" in cambios:
            v.validate_estado(cambios["estado"])
            validated["estado"] = cambios["estado"]

        self._repo.update_vehiculo(id_vehiculo, validated)
        return self._ensure_vehiculo_exists(id_vehiculo)

    # ==================================================================
    # ENTREGAS
    # ==================================================================

    def registrar_entrega(self, data: dict) -> Entrega:
        """CU-06"""
        v.validate_id_entrega(data["id_entrega"])
        v.validate_latitud(float(data["latitud"]))
        v.validate_longitud(float(data["longitud"]))
        v.validate_peso(float(data["peso_kg"]))
        v.validate_prioridad(int(data["prioridad"]))
        v.validate_ventana_horaria(data["ventana_horaria"])

        entrega = Entrega.from_dict(data)
        self._repo.insert_entrega(entrega.to_dict())
        return entrega

    def eliminar_entrega(self, id_entrega: str) -> None:
        """CU-07"""
        self._ensure_entrega_exists(id_entrega)
        self._repo.soft_delete_entrega(id_entrega)

    def obtener_entrega(self, id_entrega: str) -> Entrega:
        """CU-08"""
        return self._ensure_entrega_exists(id_entrega)

    def listar_entregas(self, pagina: int = 1, por_pagina: int = 20) -> tuple[list[Entrega], int]:
        """CU-09"""
        offset = (pagina - 1) * por_pagina
        rows = self._repo.get_all_entregas(limit=por_pagina, offset=offset)
        total = self._repo.count_entregas()
        return [Entrega.from_dict(r) for r in rows], total

    def editar_entrega(self, id_entrega: str, cambios: dict) -> Entrega:
        """CU-10"""
        self._ensure_entrega_exists(id_entrega)
        validated = {}
        field_map = {
            "latitud": (v.validate_latitud, float),
            "longitud": (v.validate_longitud, float),
            "peso_kg": (v.validate_peso, float),
            "prioridad": (v.validate_prioridad, int),
            "ventana_horaria": (v.validate_ventana_horaria, str),
        }
        for field, (validator, cast) in field_map.items():
            if field in cambios:
                validator(cast(cambios[field]))
                validated[field] = cast(cambios[field])

        self._repo.update_entrega(id_entrega, validated)
        return self._ensure_entrega_exists(id_entrega)

    # ==================================================================
    # RUTAS
    # ==================================================================

    def crear_ruta(self, id_ruta: str, id_vehiculo: str, ids_entregas: list[str]) -> Ruta:
        """CU-11: Create a route after validating battery and weight."""
        v.validate_id_ruta(id_ruta)
        vehiculo = self._ensure_vehiculo_exists(id_vehiculo)
        entregas = [self._ensure_entrega_exists(e) for e in ids_entregas]

        distancia = self._calcular_distancia(vehiculo, entregas)
        consumo = self._calcular_consumo(vehiculo, distancia)
        peso_total = sum(e.peso_kg for e in entregas)

        self._validar_bateria(vehiculo, consumo)
        self._validar_peso(vehiculo, peso_total)

        ruta_data = {
            "id_ruta": id_ruta,
            "id_vehiculo": id_vehiculo,
            "distancia_total_estimada": distancia,
            "consumo_estimado_bateria": consumo,
        }
        self._repo.insert_ruta(ruta_data, ids_entregas)
        return Ruta.from_dict(ruta_data, ids_entregas)

    def eliminar_ruta(self, id_ruta: str) -> None:
        """CU-12"""
        self._ensure_ruta_exists(id_ruta)
        self._repo.soft_delete_ruta(id_ruta)

    def obtener_ruta(self, id_ruta: str) -> Ruta:
        """CU-13"""
        return self._ensure_ruta_exists(id_ruta)

    def listar_rutas(self, pagina: int = 1, por_pagina: int = 20) -> tuple[list[dict], int]:
        """CU-14: Returns raw dicts (includes joined modelo) and total count."""
        offset = (pagina - 1) * por_pagina
        rows = self._repo.get_all_rutas(limit=por_pagina, offset=offset)
        total = self._repo.count_rutas()
        return rows, total

    def editar_ruta(self, id_ruta: str, nuevo_vehiculo_id: str | None,
                    nuevas_entregas: list[str] | None) -> Ruta:
        """CU-15: Edit vehicle and/or deliveries of a route."""
        ruta = self._ensure_ruta_exists(id_ruta)

        id_vehiculo = nuevo_vehiculo_id or ruta.id_vehiculo
        vehiculo = self._ensure_vehiculo_exists(id_vehiculo)

        ids_e = nuevas_entregas if nuevas_entregas is not None else ruta.lista_entregas
        entregas = [self._ensure_entrega_exists(e) for e in ids_e]

        distancia = self._calcular_distancia(vehiculo, entregas)
        consumo = self._calcular_consumo(vehiculo, distancia)
        peso_total = sum(e.peso_kg for e in entregas)

        self._validar_bateria(vehiculo, consumo)
        self._validar_peso(vehiculo, peso_total)

        fields = {
            "id_vehiculo": id_vehiculo,
            "distancia_total_estimada": distancia,
            "consumo_estimado_bateria": consumo,
        }
        self._repo.update_ruta(id_ruta, fields, ids_e)
        return Ruta.from_dict({**fields, "id_ruta": id_ruta}, ids_e)

    def obtener_entregas_de_ruta(self, id_ruta: str) -> list[Entrega]:
        rows = self._repo.get_entregas_de_ruta(id_ruta)
        return [Entrega.from_dict(r) for r in rows]

    def listar_vehiculos_disponibles(self) -> list[Vehiculo]:
        rows = self._repo.get_vehiculos_disponibles()
        return [Vehiculo.from_dict(r) for r in rows]

    def listar_entregas_disponibles(self) -> list[Entrega]:
        rows = self._repo.get_entregas_disponibles()
        return [Entrega.from_dict(r) for r in rows]

    # ==================================================================
    # Private helpers
    # ==================================================================

    def _ensure_vehiculo_exists(self, id_vehiculo: str) -> Vehiculo:
        row = self._repo.get_vehiculo_by_id(id_vehiculo)
        if not row:
            raise NotFoundError("Vehiculo", id_vehiculo)
        return Vehiculo.from_dict(row)

    def _ensure_entrega_exists(self, id_entrega: str) -> Entrega:
        row = self._repo.get_entrega_by_id(id_entrega)
        if not row:
            raise NotFoundError("Entrega", id_entrega)
        return Entrega.from_dict(row)

    def _ensure_ruta_exists(self, id_ruta: str) -> Ruta:
        row = self._repo.get_ruta_by_id(id_ruta)
        if not row:
            raise NotFoundError("Ruta", id_ruta)
        entregas_rows = self._repo.get_entregas_de_ruta(id_ruta)
        ids = [r["id_entrega"] for r in entregas_rows]
        return Ruta.from_dict(row, ids)

    @staticmethod
    def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Great-circle distance in km between two coordinates."""
        R = 6371.0
        phi1, phi2 = math.radians(lat1), math.radians(lat2)
        dphi = math.radians(lat2 - lat1)
        dlambda = math.radians(lon2 - lon1)
        a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
        return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    def _calcular_distancia(self, vehiculo: Vehiculo, entregas: list[Entrega]) -> float:
        """Sum of haversine segments: depot(0,0) → e1 → e2 … → eN."""
        if not entregas:
            return 0.0
        # Simplified: depot at (0, 0) — replace with a real depot coordinate if needed
        total = 0.0
        prev_lat, prev_lon = 0.0, 0.0
        for e in entregas:
            total += self._haversine_km(prev_lat, prev_lon, e.latitud, e.longitud)
            prev_lat, prev_lon = e.latitud, e.longitud
        return round(total, 2)

    def _calcular_consumo(self, vehiculo: Vehiculo, distancia_km: float) -> float:
        """Estimated battery percentage consumed for a given distance."""
        if vehiculo.capacidad_bateria_total == 0:
            return 0.0
        kwh_needed = distancia_km * KWH_PER_KM
        return round((kwh_needed / vehiculo.capacidad_bateria_total) * 100, 2)

    @staticmethod
    def _validar_bateria(vehiculo: Vehiculo, consumo: float) -> None:
        if consumo > BATTERY_SAFETY_LIMIT:
            raise InsufficientBatteryError(consumo, vehiculo.nivel_bateria_actual)
        if consumo > vehiculo.nivel_bateria_actual:
            raise InsufficientBatteryError(consumo, vehiculo.nivel_bateria_actual)

    @staticmethod
    def _validar_peso(vehiculo: Vehiculo, peso_total: float) -> None:
        # Max load = 10 % of battery capacity in kg (simplified heuristic)
        # In a real system this would be a vehicle attribute
        max_kg = vehiculo.capacidad_bateria_total * 10
        if peso_total > max_kg:
            raise OverweightError(peso_total, max_kg)
