# logic/validators.py — Validaciones sin efectos secundarios
# Devuelven True o lanzan ValidationError.

import re
from exceptions import ValidationError
from logic.models import EstadoVehiculo

# ---------------------------------------------------------------
# Vehiculo
# ---------------------------------------------------------------
ID_VEHICULO_PATTERN = re.compile(r"^[A-Za-z0-9\-]{3,20}$")


def validate_id_vehiculo(value: str) -> bool:
    if not ID_VEHICULO_PATTERN.match(value):
        raise ValidationError("id_vehiculo", "Must be 3–20 alphanumeric characters (hyphens allowed). E.g. VAN-001")
    return True


def validate_modelo(value: str) -> bool:
    if not value or len(value) > 100:
        raise ValidationError("modelo", "Model name must be 1–100 characters.")
    return True


def validate_capacidad_bateria(value: float) -> bool:
    if value <= 0:
        raise ValidationError("capacidad_bateria_total", "Battery capacity must be a positive number (kWh).")
    return True


def validate_nivel_bateria(value: float) -> bool:
    if not (0 <= value <= 100):
        raise ValidationError("nivel_bateria_actual", "Battery level must be between 0 and 100 (%).")
    return True


def validate_autonomia(value: int) -> bool:
    if value <= 0:
        raise ValidationError("autonomia_maxima_km", "Max range must be a positive integer (km).")
    return True


def validate_estado(value: str) -> bool:
    valid = {e.value for e in EstadoVehiculo}
    if value not in valid:
        raise ValidationError("estado", f"State must be one of: {', '.join(valid)}")
    return True


# ---------------------------------------------------------------
# Entrega
# ---------------------------------------------------------------
ID_ENTREGA_PATTERN = re.compile(r"^[A-Za-z0-9\-]{3,20}$")
VENTANA_PATTERN = re.compile(r"^\d{2}:\d{2} - \d{2}:\d{2}$")


def validate_id_entrega(value: str) -> bool:
    if not ID_ENTREGA_PATTERN.match(value):
        raise ValidationError("id_entrega", "Must be 3–20 alphanumeric characters (hyphens allowed).")
    return True


def validate_latitud(value: float) -> bool:
    if not (-90 <= value <= 90):
        raise ValidationError("latitud", "Latitude must be between -90 and 90.")
    return True


def validate_longitud(value: float) -> bool:
    if not (-180 <= value <= 180):
        raise ValidationError("longitud", "Longitude must be between -180 and 180.")
    return True


def validate_peso(value: float) -> bool:
    if value <= 0:
        raise ValidationError("peso_kg", "Weight must be a positive number (kg).")
    return True


def validate_prioridad(value: int) -> bool:
    if value not in (1, 2, 3):
        raise ValidationError("prioridad", "Priority must be 1 (low), 2 (medium) or 3 (high).")
    return True


def validate_ventana_horaria(value: str) -> bool:
    if not VENTANA_PATTERN.match(value):
        raise ValidationError("ventana_horaria", "Format must be HH:MM - HH:MM. E.g. 09:00 - 11:00")
    return True


# ---------------------------------------------------------------
# Ruta
# ---------------------------------------------------------------
ID_RUTA_PATTERN = re.compile(r"^[A-Za-z0-9\-]{3,20}$")


def validate_id_ruta(value: str) -> bool:
    if not ID_RUTA_PATTERN.match(value):
        raise ValidationError("id_ruta", "Must be 3–20 alphanumeric characters (hyphens allowed).")
    return True
