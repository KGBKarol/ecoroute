# db/connection.py — Gestión de la conexión a MySQL

import os
from dotenv import load_dotenv
import mysql.connector
from mysql.connector import MySQLConnection
from exceptions import DatabaseError

load_dotenv()


class DatabaseConnection:
    """Manages the MySQL connection lifecycle."""

    def __init__(self):
        self._connection: MySQLConnection | None = None

    def connect(self) -> None:
        """Open the database connection using environment variables."""
        try:
            self._connection = mysql.connector.connect(
                host=os.getenv("DB_HOST", "localhost"),
                port=int(os.getenv("DB_PORT", 3306)),
                database=os.getenv("DB_NAME"),
                user=os.getenv("DB_USER"),
                password=os.getenv("DB_PASSWORD"),
                autocommit=False,
            )
        except mysql.connector.Error as e:
            raise DatabaseError(f"Could not connect to database: {e}") from e

    def disconnect(self) -> None:
        """Close the database connection if open."""
        if self._connection and self._connection.is_connected():
            self._connection.close()
            self._connection = None

    def get_connection(self) -> MySQLConnection:
        """Return the active connection, raising if not connected."""
        if self._connection is None or not self._connection.is_connected():
            raise DatabaseError("No active database connection.")
        return self._connection
