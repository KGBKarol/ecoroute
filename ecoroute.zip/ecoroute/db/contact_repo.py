# db/contact_repo.py — Repositorio de acceso a datos

from __future__ import annotations
from typing import Any
from db.connection import DatabaseConnection
from exceptions import DatabaseError


class EcorouteRepository:
    """All SQL operations. Every query uses parameterised statements (%s)."""

    def __init__(self, db: DatabaseConnection):
        self._db = db

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _cursor(self):
        return self._db.get_connection().cursor(dictionary=True)

    def _commit(self) -> None:
        self._db.get_connection().commit()

    def _rollback(self) -> None:
        self._db.get_connection().rollback()

    # ==================================================================
    # VEHICULOS
    # ==================================================================

    def insert_vehiculo(self, v: dict) -> None:
        sql = """
            INSERT INTO vehiculos
                (id_vehiculo, modelo, capacidad_bateria_total,
                 nivel_bateria_actual, autonomia_maxima_km, estado)
            VALUES (%s, %s, %s, %s, %s, %s)
        """
        try:
            cur = self._cursor()
            cur.execute(sql, (
                v["id_vehiculo"], v["modelo"],
                v["capacidad_bateria_total"], v["nivel_bateria_actual"],
                v["autonomia_maxima_km"], v["estado"],
            ))
            self._commit()
        except Exception as e:
            self._rollback()
            raise DatabaseError(f"insert_vehiculo failed: {e}") from e

    def get_vehiculo_by_id(self, id_vehiculo: str) -> dict | None:
        sql = "SELECT * FROM vehiculos WHERE id_vehiculo = %s AND deleted_at IS NULL"
        cur = self._cursor()
        cur.execute(sql, (id_vehiculo,))
        return cur.fetchone()

    def get_all_vehiculos(self, limit: int = 20, offset: int = 0) -> list[dict]:
        sql = """
            SELECT * FROM vehiculos
            WHERE deleted_at IS NULL
            ORDER BY id_vehiculo
            LIMIT %s OFFSET %s
        """
        cur = self._cursor()
        cur.execute(sql, (limit, offset))
        return cur.fetchall()

    def count_vehiculos(self) -> int:
        sql = "SELECT COUNT(*) AS total FROM vehiculos WHERE deleted_at IS NULL"
        cur = self._cursor()
        cur.execute(sql)
        return cur.fetchone()["total"]

    def update_vehiculo(self, id_vehiculo: str, fields: dict) -> None:
        if not fields:
            return
        set_clause = ", ".join(f"{k} = %s" for k in fields)
        values = list(fields.values()) + [id_vehiculo]
        sql = f"UPDATE vehiculos SET {set_clause} WHERE id_vehiculo = %s AND deleted_at IS NULL"
        try:
            cur = self._cursor()
            cur.execute(sql, values)
            self._commit()
        except Exception as e:
            self._rollback()
            raise DatabaseError(f"update_vehiculo failed: {e}") from e

    def soft_delete_vehiculo(self, id_vehiculo: str) -> None:
        sql = "UPDATE vehiculos SET deleted_at = NOW() WHERE id_vehiculo = %s AND deleted_at IS NULL"
        try:
            cur = self._cursor()
            cur.execute(sql, (id_vehiculo,))
            self._commit()
        except Exception as e:
            self._rollback()
            raise DatabaseError(f"soft_delete_vehiculo failed: {e}") from e

    def get_vehiculos_disponibles(self) -> list[dict]:
        sql = "SELECT * FROM vehiculos WHERE estado = 'disponible' AND deleted_at IS NULL"
        cur = self._cursor()
        cur.execute(sql)
        return cur.fetchall()

    # ==================================================================
    # ENTREGAS
    # ==================================================================

    def insert_entrega(self, e: dict) -> None:
        sql = """
            INSERT INTO entregas
                (id_entrega, latitud, longitud, peso_kg, prioridad, ventana_horaria)
            VALUES (%s, %s, %s, %s, %s, %s)
        """
        try:
            cur = self._cursor()
            cur.execute(sql, (
                e["id_entrega"], e["latitud"], e["longitud"],
                e["peso_kg"], e["prioridad"], e["ventana_horaria"],
            ))
            self._commit()
        except Exception as ex:
            self._rollback()
            raise DatabaseError(f"insert_entrega failed: {ex}") from ex

    def get_entrega_by_id(self, id_entrega: str) -> dict | None:
        sql = "SELECT * FROM entregas WHERE id_entrega = %s AND deleted_at IS NULL"
        cur = self._cursor()
        cur.execute(sql, (id_entrega,))
        return cur.fetchone()

    def get_all_entregas(self, limit: int = 20, offset: int = 0) -> list[dict]:
        sql = """
            SELECT * FROM entregas
            WHERE deleted_at IS NULL
            ORDER BY id_entrega
            LIMIT %s OFFSET %s
        """
        cur = self._cursor()
        cur.execute(sql, (limit, offset))
        return cur.fetchall()

    def count_entregas(self) -> int:
        sql = "SELECT COUNT(*) AS total FROM entregas WHERE deleted_at IS NULL"
        cur = self._cursor()
        cur.execute(sql)
        return cur.fetchone()["total"]

    def update_entrega(self, id_entrega: str, fields: dict) -> None:
        if not fields:
            return
        set_clause = ", ".join(f"{k} = %s" for k in fields)
        values = list(fields.values()) + [id_entrega]
        sql = f"UPDATE entregas SET {set_clause} WHERE id_entrega = %s AND deleted_at IS NULL"
        try:
            cur = self._cursor()
            cur.execute(sql, values)
            self._commit()
        except Exception as e:
            self._rollback()
            raise DatabaseError(f"update_entrega failed: {e}") from e

    def soft_delete_entrega(self, id_entrega: str) -> None:
        sql = "UPDATE entregas SET deleted_at = NOW() WHERE id_entrega = %s AND deleted_at IS NULL"
        try:
            cur = self._cursor()
            cur.execute(sql, (id_entrega,))
            self._commit()
        except Exception as e:
            self._rollback()
            raise DatabaseError(f"soft_delete_entrega failed: {e}") from e

    def get_entregas_disponibles(self) -> list[dict]:
        """Entregas not already assigned to a route."""
        sql = """
            SELECT e.* FROM entregas e
            WHERE e.deleted_at IS NULL
              AND e.id_entrega NOT IN (
                  SELECT re.id_entrega FROM ruta_entregas re
                  JOIN rutas r ON re.id_ruta = r.id_ruta
                  WHERE r.deleted_at IS NULL
              )
        """
        cur = self._cursor()
        cur.execute(sql)
        return cur.fetchall()

    # ==================================================================
    # RUTAS
    # ==================================================================

    def insert_ruta(self, r: dict, entregas_ordenadas: list[str]) -> None:
        sql_ruta = """
            INSERT INTO rutas
                (id_ruta, id_vehiculo, distancia_total_estimada, consumo_estimado_bateria)
            VALUES (%s, %s, %s, %s)
        """
        sql_re = "INSERT INTO ruta_entregas (id_ruta, id_entrega, orden) VALUES (%s, %s, %s)"
        try:
            cur = self._cursor()
            cur.execute(sql_ruta, (
                r["id_ruta"], r["id_vehiculo"],
                r["distancia_total_estimada"], r["consumo_estimado_bateria"],
            ))
            for orden, id_entrega in enumerate(entregas_ordenadas, start=1):
                cur.execute(sql_re, (r["id_ruta"], id_entrega, orden))
            self._commit()
        except Exception as e:
            self._rollback()
            raise DatabaseError(f"insert_ruta failed: {e}") from e

    def get_ruta_by_id(self, id_ruta: str) -> dict | None:
        sql = "SELECT * FROM rutas WHERE id_ruta = %s AND deleted_at IS NULL"
        cur = self._cursor()
        cur.execute(sql, (id_ruta,))
        return cur.fetchone()

    def get_entregas_de_ruta(self, id_ruta: str) -> list[dict]:
        sql = """
            SELECT e.*, re.orden FROM entregas e
            JOIN ruta_entregas re ON e.id_entrega = re.id_entrega
            WHERE re.id_ruta = %s
            ORDER BY re.orden
        """
        cur = self._cursor()
        cur.execute(sql, (id_ruta,))
        return cur.fetchall()

    def get_all_rutas(self, limit: int = 20, offset: int = 0) -> list[dict]:
        sql = """
            SELECT r.*, v.modelo FROM rutas r
            JOIN vehiculos v ON r.id_vehiculo = v.id_vehiculo
            WHERE r.deleted_at IS NULL
            ORDER BY r.id_ruta
            LIMIT %s OFFSET %s
        """
        cur = self._cursor()
        cur.execute(sql, (limit, offset))
        return cur.fetchall()

    def count_rutas(self) -> int:
        sql = "SELECT COUNT(*) AS total FROM rutas WHERE deleted_at IS NULL"
        cur = self._cursor()
        cur.execute(sql)
        return cur.fetchone()["total"]

    def update_ruta(self, id_ruta: str, fields: dict, nuevas_entregas: list[str] | None = None) -> None:
        try:
            cur = self._cursor()
            if fields:
                set_clause = ", ".join(f"{k} = %s" for k in fields)
                values = list(fields.values()) + [id_ruta]
                cur.execute(
                    f"UPDATE rutas SET {set_clause} WHERE id_ruta = %s AND deleted_at IS NULL",
                    values,
                )
            if nuevas_entregas is not None:
                cur.execute("DELETE FROM ruta_entregas WHERE id_ruta = %s", (id_ruta,))
                sql_re = "INSERT INTO ruta_entregas (id_ruta, id_entrega, orden) VALUES (%s, %s, %s)"
                for orden, id_entrega in enumerate(nuevas_entregas, start=1):
                    cur.execute(sql_re, (id_ruta, id_entrega, orden))
            self._commit()
        except Exception as e:
            self._rollback()
            raise DatabaseError(f"update_ruta failed: {e}") from e

    def soft_delete_ruta(self, id_ruta: str) -> None:
        sql = "UPDATE rutas SET deleted_at = NOW() WHERE id_ruta = %s AND deleted_at IS NULL"
        try:
            cur = self._cursor()
            cur.execute(sql, (id_ruta,))
            self._commit()
        except Exception as e:
            self._rollback()
            raise DatabaseError(f"soft_delete_ruta failed: {e}") from e
