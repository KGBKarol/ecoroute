-- migrations/create_tables.sql
-- Esquema de base de datos para EcoRoute

CREATE DATABASE IF NOT EXISTS ecoroute_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE ecoroute_db;

-- -------------------------------------------------------
-- Tabla: vehiculos
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS vehiculos (
    id_vehiculo     VARCHAR(20)     NOT NULL,
    modelo          VARCHAR(100)    NOT NULL,
    capacidad_bateria_total   FLOAT NOT NULL,
    nivel_bateria_actual      FLOAT NOT NULL,
    autonomia_maxima_km       INT   NOT NULL,
    estado          ENUM('disponible', 'en_ruta', 'cargando', 'mantenimiento') NOT NULL DEFAULT 'disponible',
    deleted_at      DATETIME        NULL DEFAULT NULL,
    PRIMARY KEY (id_vehiculo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- Tabla: entregas
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS entregas (
    id_entrega      VARCHAR(20)     NOT NULL,
    latitud         DECIMAL(9,6)    NOT NULL,
    longitud        DECIMAL(9,6)    NOT NULL,
    peso_kg         FLOAT           NOT NULL,
    prioridad       TINYINT         NOT NULL,
    ventana_horaria VARCHAR(20)     NOT NULL,
    deleted_at      DATETIME        NULL DEFAULT NULL,
    PRIMARY KEY (id_entrega)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- Tabla: rutas
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS rutas (
    id_ruta                     VARCHAR(20) NOT NULL,
    id_vehiculo                 VARCHAR(20) NOT NULL,
    distancia_total_estimada    FLOAT       NOT NULL,
    consumo_estimado_bateria    FLOAT       NOT NULL,
    deleted_at                  DATETIME    NULL DEFAULT NULL,
    PRIMARY KEY (id_ruta),
    FOREIGN KEY (id_vehiculo) REFERENCES vehiculos(id_vehiculo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- Tabla: ruta_entregas  (relación N:M ordenada)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS ruta_entregas (
    id_ruta         VARCHAR(20) NOT NULL,
    id_entrega      VARCHAR(20) NOT NULL,
    orden           INT         NOT NULL,
    PRIMARY KEY (id_ruta, id_entrega),
    FOREIGN KEY (id_ruta)    REFERENCES rutas(id_ruta),
    FOREIGN KEY (id_entrega) REFERENCES entregas(id_entrega)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- Usuario de la aplicación (ejecutar como root en MySQL)
-- -------------------------------------------------------
-- CREATE USER IF NOT EXISTS 'ecoroute_user'@'localhost' IDENTIFIED BY 'tu_contraseña_segura';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON ecoroute_db.* TO 'ecoroute_user'@'localhost';
-- FLUSH PRIVILEGES;
