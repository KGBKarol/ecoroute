# exceptions.py — Jerarquía de excepciones del proyecto


class EcorouteError(Exception):
    """Base exception for all application errors."""
    pass


class ValidationError(EcorouteError):
    """Raised when input data fails validation."""
    def __init__(self, field: str, message: str):
        self.field = field
        self.message = message
        super().__init__(f"[{field}] {message}")


class NotFoundError(EcorouteError):
    """Raised when a requested resource does not exist."""
    def __init__(self, resource: str, identifier: str):
        self.resource = resource
        self.identifier = identifier
        super().__init__(f"{resource} '{identifier}' not found.")


class DatabaseError(EcorouteError):
    """Raised when a database operation fails."""
    pass


class InsufficientBatteryError(EcorouteError):
    """Raised when a vehicle does not have enough battery for a route."""
    def __init__(self, required: float, available: float):
        self.required = required
        self.available = available
        super().__init__(
            f"Insufficient battery. Required: {required:.1f}%, Available: {available:.1f}%."
        )


class OverweightError(EcorouteError):
    """Raised when deliveries exceed vehicle load capacity."""
    def __init__(self, total_kg: float, max_kg: float):
        self.total_kg = total_kg
        self.max_kg = max_kg
        super().__init__(
            f"Total weight {total_kg:.1f} kg exceeds vehicle capacity {max_kg:.1f} kg."
        )
