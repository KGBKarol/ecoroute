# main.py — Punto de entrada de la aplicación EcoRoute

from db.connection import DatabaseConnection
from db.contact_repo import EcorouteRepository
from logic.services import EcorouteService
from cli.menu import run_main_menu
from exceptions import DatabaseError


def main() -> None:
    db = DatabaseConnection()
    try:
        db.connect()
    except DatabaseError as e:
        print(f"\n  ERROR DE CONEXIÓN: {e}")
        print("  Comprueba tu archivo .env y que MySQL esté arrancado.\n")
        return

    repo = EcorouteRepository(db)
    svc = EcorouteService(repo)

    try:
        run_main_menu(svc)
    finally:
        db.disconnect()


if __name__ == "__main__":
    main()
