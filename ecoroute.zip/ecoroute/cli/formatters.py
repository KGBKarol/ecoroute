# cli/formatters.py — Funciones de presentación puras (sin lógica de negocio)

from tabulate import tabulate
from logic.models import Vehiculo, Entrega, Ruta


def fmt_vehiculo(v: Vehiculo) -> str:
    rows = [
        ["ID",              v.id_vehiculo],
        ["Modelo",          v.modelo],
        ["Batería total",   f"{v.capacidad_bateria_total} kWh"],
        ["Nivel batería",   f"{v.nivel_bateria_actual} %"],
        ["Autonomía máx.",  f"{v.autonomia_maxima_km} km"],
        ["Autonomía act.",  f"{v.autonomia_actual_km():.1f} km"],
        ["Estado",          v.estado.value],
    ]
    return tabulate(rows, tablefmt="simple")


def fmt_vehiculos_tabla(vehiculos: list[Vehiculo]) -> str:
    if not vehiculos:
        return "  (no vehicles found)"
    headers = ["ID", "Modelo", "Batería %", "Autonomía km", "Estado"]
    rows = [
        [v.id_vehiculo, v.modelo, f"{v.nivel_bateria_actual}%",
         v.autonomia_maxima_km, v.estado.value]
        for v in vehiculos
    ]
    return tabulate(rows, headers=headers, tablefmt="grid")


def fmt_entrega(e: Entrega) -> str:
    rows = [
        ["ID",              e.id_entrega],
        ["Coordenadas",     f"({e.latitud}, {e.longitud})"],
        ["Peso",            f"{e.peso_kg} kg"],
        ["Prioridad",       e.prioridad],
        ["Ventana horaria", e.ventana_horaria],
    ]
    return tabulate(rows, tablefmt="simple")


def fmt_entregas_tabla(entregas: list[Entrega]) -> str:
    if not entregas:
        return "  (no deliveries found)"
    headers = ["ID", "Coordenadas", "Peso kg", "Prioridad", "Ventana"]
    rows = [
        [e.id_entrega, f"({e.latitud}, {e.longitud})",
         e.peso_kg, e.prioridad, e.ventana_horaria]
        for e in entregas
    ]
    return tabulate(rows, headers=headers, tablefmt="grid")


def fmt_ruta(r: Ruta, modelo_vehiculo: str = "") -> str:
    rows = [
        ["ID ruta",       r.id_ruta],
        ["Vehículo",      f"{r.id_vehiculo} {('(' + modelo_vehiculo + ')') if modelo_vehiculo else ''}"],
        ["Entregas",      ", ".join(r.lista_entregas) or "—"],
        ["Distancia est.", f"{r.distancia_total_estimada} km"],
        ["Consumo est.",  f"{r.consumo_estimado_bateria} %"],
    ]
    return tabulate(rows, tablefmt="simple")


def fmt_rutas_tabla(rutas: list[dict]) -> str:
    if not rutas:
        return "  (no routes found)"
    headers = ["ID ruta", "Vehículo", "Modelo", "Distancia km", "Consumo %"]
    rows = [
        [r["id_ruta"], r["id_vehiculo"], r.get("modelo", ""),
         r["distancia_total_estimada"], r["consumo_estimado_bateria"]]
        for r in rutas
    ]
    return tabulate(rows, headers=headers, tablefmt="grid")


def fmt_pagination(pagina: int, total_paginas: int, total: int) -> str:
    return f"  Página {pagina}/{total_paginas}  |  Total: {total} registros"


def fmt_error(msg: str) -> str:
    return f"\n  ✗ Error: {msg}\n"


def fmt_ok(msg: str) -> str:
    return f"\n  ✓ {msg}\n"


def fmt_separador() -> str:
    return "─" * 60
