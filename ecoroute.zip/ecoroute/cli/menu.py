# cli/menu.py — Menú principal y submenús

from __future__ import annotations
import math
from logic.services import EcorouteService
from logic.models import EstadoVehiculo
from exceptions import EcorouteError
from cli import formatters as fmt


PAGE_SIZE = 20


# ─────────────────────────────────────────────────────────────
# Helpers de entrada
# ─────────────────────────────────────────────────────────────

def _input(prompt: str) -> str:
    return input(f"  {prompt}: ").strip()


def _confirm(msg: str) -> bool:
    ans = input(f"  {msg} [s/N]: ").strip().lower()
    return ans == "s"


def _pause() -> None:
    input("\n  Pulsa ENTER para continuar...")


def _header(title: str) -> None:
    print(f"\n{fmt.fmt_separador()}")
    print(f"  {title}")
    print(fmt.fmt_separador())


# ─────────────────────────────────────────────────────────────
# Menú raíz
# ─────────────────────────────────────────────────────────────

def run_main_menu(svc: EcorouteService) -> None:
    while True:
        _header("ECOROUTE — Menú principal")
        print("  1. Gestión de Vehículos")
        print("  2. Gestión de Entregas")
        print("  3. Gestión de Rutas")
        print("  0. Salir")
        choice = _input("Opción")
        if choice == "1":
            run_vehiculos_menu(svc)
        elif choice == "2":
            run_entregas_menu(svc)
        elif choice == "3":
            run_rutas_menu(svc)
        elif choice == "0":
            print("\n  ¡Hasta luego!\n")
            break
        else:
            print(fmt.fmt_error("Opción no válida."))


# ─────────────────────────────────────────────────────────────
# Vehículos
# ─────────────────────────────────────────────────────────────

def run_vehiculos_menu(svc: EcorouteService) -> None:
    while True:
        _header("VEHÍCULOS")
        print("  1. Registrar vehículo")
        print("  2. Eliminar vehículo")
        print("  3. Ver datos de un vehículo")
        print("  4. Listar todos los vehículos")
        print("  5. Editar vehículo")
        print("  0. Volver")
        choice = _input("Opción")
        try:
            if choice == "1":
                _cu01_registrar_vehiculo(svc)
            elif choice == "2":
                _cu02_eliminar_vehiculo(svc)
            elif choice == "3":
                _cu03_ver_vehiculo(svc)
            elif choice == "4":
                _cu04_listar_vehiculos(svc)
            elif choice == "5":
                _cu05_editar_vehiculo(svc)
            elif choice == "0":
                break
            else:
                print(fmt.fmt_error("Opción no válida."))
        except EcorouteError as e:
            print(fmt.fmt_error(str(e)))
            _pause()


def _cu01_registrar_vehiculo(svc: EcorouteService) -> None:
    _header("Registrar vehículo")
    estados = [e.value for e in EstadoVehiculo]
    data = {
        "id_vehiculo":            _input("ID (ej: VAN-001)"),
        "modelo":                 _input("Modelo"),
        "capacidad_bateria_total": _input("Capacidad batería total (kWh)"),
        "nivel_bateria_actual":   _input("Nivel batería actual (0-100 %)"),
        "autonomia_maxima_km":    _input("Autonomía máxima (km)"),
        "estado":                 _input(f"Estado ({'/'.join(estados)})"),
    }
    vehiculo = svc.registrar_vehiculo(data)
    print(fmt.fmt_ok(f"Vehículo '{vehiculo.id_vehiculo}' registrado."))
    print(fmt.fmt_vehiculo(vehiculo))
    _pause()


def _cu02_eliminar_vehiculo(svc: EcorouteService) -> None:
    _header("Eliminar vehículo")
    vehiculos, _ = svc.listar_vehiculos(pagina=1, por_pagina=100)
    print(fmt.fmt_vehiculos_tabla(vehiculos))
    id_v = _input("ID del vehículo a eliminar")
    if _confirm(f"¿Eliminar vehículo '{id_v}'?"):
        svc.eliminar_vehiculo(id_v)
        print(fmt.fmt_ok(f"Vehículo '{id_v}' eliminado."))
    else:
        print("  Operación cancelada.")
    _pause()


def _cu03_ver_vehiculo(svc: EcorouteService) -> None:
    _header("Ver datos de vehículo")
    id_v = _input("ID del vehículo")
    vehiculo = svc.obtener_vehiculo(id_v)
    print(fmt.fmt_vehiculo(vehiculo))
    _pause()


def _cu04_listar_vehiculos(svc: EcorouteService) -> None:
    pagina = 1
    while True:
        _header("Listado de vehículos")
        vehiculos, total = svc.listar_vehiculos(pagina=pagina, por_pagina=PAGE_SIZE)
        total_paginas = max(1, math.ceil(total / PAGE_SIZE))
        print(fmt.fmt_vehiculos_tabla(vehiculos))
        print(fmt.fmt_pagination(pagina, total_paginas, total))
        print("\n  [N] Siguiente  [A] Anterior  [0] Volver")
        nav = _input("Opción").upper()
        if nav == "N" and pagina < total_paginas:
            pagina += 1
        elif nav == "A" and pagina > 1:
            pagina -= 1
        elif nav == "0":
            break


def _cu05_editar_vehiculo(svc: EcorouteService) -> None:
    _header("Editar vehículo")
    vehiculos, _ = svc.listar_vehiculos(pagina=1, por_pagina=100)
    print(fmt.fmt_vehiculos_tabla(vehiculos))
    id_v = _input("ID del vehículo a editar")
    vehiculo = svc.obtener_vehiculo(id_v)
    print(fmt.fmt_vehiculo(vehiculo))
    print("\n  (Deja vacío para mantener el valor actual)")
    cambios = {}
    campos = [
        ("modelo",                 "Modelo",                  str),
        ("capacidad_bateria_total","Capacidad batería (kWh)",  float),
        ("nivel_bateria_actual",   "Nivel batería (0-100 %)", float),
        ("autonomia_maxima_km",    "Autonomía máxima (km)",   int),
        ("estado",                 "Estado",                  str),
    ]
    for field, label, _ in campos:
        val = _input(label)
        if val:
            cambios[field] = val
    if cambios:
        actualizado = svc.editar_vehiculo(id_v, cambios)
        print(fmt.fmt_ok("Vehículo actualizado."))
        print(fmt.fmt_vehiculo(actualizado))
    else:
        print("  Sin cambios.")
    _pause()


# ─────────────────────────────────────────────────────────────
# Entregas
# ─────────────────────────────────────────────────────────────

def run_entregas_menu(svc: EcorouteService) -> None:
    while True:
        _header("ENTREGAS")
        print("  1. Añadir entrega")
        print("  2. Eliminar entrega")
        print("  3. Ver datos de una entrega")
        print("  4. Listar todas las entregas")
        print("  5. Editar entrega")
        print("  0. Volver")
        choice = _input("Opción")
        try:
            if choice == "1":
                _cu06_registrar_entrega(svc)
            elif choice == "2":
                _cu07_eliminar_entrega(svc)
            elif choice == "3":
                _cu08_ver_entrega(svc)
            elif choice == "4":
                _cu09_listar_entregas(svc)
            elif choice == "5":
                _cu10_editar_entrega(svc)
            elif choice == "0":
                break
            else:
                print(fmt.fmt_error("Opción no válida."))
        except EcorouteError as e:
            print(fmt.fmt_error(str(e)))
            _pause()


def _cu06_registrar_entrega(svc: EcorouteService) -> None:
    _header("Añadir entrega")
    data = {
        "id_entrega":      _input("ID entrega (ej: ENT-001)"),
        "latitud":         _input("Latitud (ej: 36.712345)"),
        "longitud":        _input("Longitud (ej: -4.421234)"),
        "peso_kg":         _input("Peso (kg)"),
        "prioridad":       _input("Prioridad (1=baja, 2=media, 3=alta)"),
        "ventana_horaria": _input("Ventana horaria (ej: 09:00 - 11:00)"),
    }
    entrega = svc.registrar_entrega(data)
    print(fmt.fmt_ok(f"Entrega '{entrega.id_entrega}' registrada."))
    print(fmt.fmt_entrega(entrega))
    _pause()


def _cu07_eliminar_entrega(svc: EcorouteService) -> None:
    _header("Eliminar entrega")
    entregas, _ = svc.listar_entregas(pagina=1, por_pagina=100)
    print(fmt.fmt_entregas_tabla(entregas))
    id_e = _input("ID de la entrega a eliminar")
    if _confirm(f"¿Eliminar entrega '{id_e}'?"):
        svc.eliminar_entrega(id_e)
        print(fmt.fmt_ok(f"Entrega '{id_e}' eliminada."))
    else:
        print("  Operación cancelada.")
    _pause()


def _cu08_ver_entrega(svc: EcorouteService) -> None:
    _header("Ver datos de entrega")
    id_e = _input("ID de la entrega")
    entrega = svc.obtener_entrega(id_e)
    print(fmt.fmt_entrega(entrega))
    _pause()


def _cu09_listar_entregas(svc: EcorouteService) -> None:
    pagina = 1
    while True:
        _header("Listado de entregas")
        entregas, total = svc.listar_entregas(pagina=pagina, por_pagina=PAGE_SIZE)
        total_paginas = max(1, math.ceil(total / PAGE_SIZE))
        print(fmt.fmt_entregas_tabla(entregas))
        print(fmt.fmt_pagination(pagina, total_paginas, total))
        print("\n  [N] Siguiente  [A] Anterior  [0] Volver")
        nav = _input("Opción").upper()
        if nav == "N" and pagina < total_paginas:
            pagina += 1
        elif nav == "A" and pagina > 1:
            pagina -= 1
        elif nav == "0":
            break


def _cu10_editar_entrega(svc: EcorouteService) -> None:
    _header("Editar entrega")
    entregas, _ = svc.listar_entregas(pagina=1, por_pagina=100)
    print(fmt.fmt_entregas_tabla(entregas))
    id_e = _input("ID de la entrega a editar")
    entrega = svc.obtener_entrega(id_e)
    print(fmt.fmt_entrega(entrega))
    print("\n  (Deja vacío para mantener el valor actual)")
    cambios = {}
    campos = [
        ("latitud",         "Latitud"),
        ("longitud",        "Longitud"),
        ("peso_kg",         "Peso (kg)"),
        ("prioridad",       "Prioridad (1-3)"),
        ("ventana_horaria", "Ventana horaria"),
    ]
    for field, label in campos:
        val = _input(label)
        if val:
            cambios[field] = val
    if cambios:
        actualizada = svc.editar_entrega(id_e, cambios)
        print(fmt.fmt_ok("Entrega actualizada."))
        print(fmt.fmt_entrega(actualizada))
    else:
        print("  Sin cambios.")
    _pause()


# ─────────────────────────────────────────────────────────────
# Rutas
# ─────────────────────────────────────────────────────────────

def run_rutas_menu(svc: EcorouteService) -> None:
    while True:
        _header("RUTAS")
        print("  1. Crear ruta")
        print("  2. Eliminar ruta")
        print("  3. Ver datos de una ruta")
        print("  4. Listar todas las rutas")
        print("  5. Editar ruta")
        print("  0. Volver")
        choice = _input("Opción")
        try:
            if choice == "1":
                _cu11_crear_ruta(svc)
            elif choice == "2":
                _cu12_eliminar_ruta(svc)
            elif choice == "3":
                _cu13_ver_ruta(svc)
            elif choice == "4":
                _cu14_listar_rutas(svc)
            elif choice == "5":
                _cu15_editar_ruta(svc)
            elif choice == "0":
                break
            else:
                print(fmt.fmt_error("Opción no válida."))
        except EcorouteError as e:
            print(fmt.fmt_error(str(e)))
            _pause()


def _cu11_crear_ruta(svc: EcorouteService) -> None:
    _header("Crear ruta")
    id_ruta = _input("ID de la nueva ruta (ej: RUT-001)")

    vehiculos = svc.listar_vehiculos_disponibles()
    if not vehiculos:
        print(fmt.fmt_error("No hay vehículos disponibles."))
        _pause()
        return
    print(fmt.fmt_vehiculos_tabla(vehiculos))
    id_vehiculo = _input("ID del vehículo a asignar")

    entregas = svc.listar_entregas_disponibles()
    if not entregas:
        print(fmt.fmt_error("No hay entregas disponibles."))
        _pause()
        return
    print(fmt.fmt_entregas_tabla(entregas))
    ids_raw = _input("IDs de entregas separados por coma (ej: ENT-001,ENT-002)")
    ids_entregas = [x.strip() for x in ids_raw.split(",") if x.strip()]

    ruta = svc.crear_ruta(id_ruta, id_vehiculo, ids_entregas)
    print(fmt.fmt_ok(f"Ruta '{ruta.id_ruta}' creada."))
    print(fmt.fmt_ruta(ruta))
    _pause()


def _cu12_eliminar_ruta(svc: EcorouteService) -> None:
    _header("Eliminar ruta")
    rutas, _ = svc.listar_rutas(pagina=1, por_pagina=100)
    print(fmt.fmt_rutas_tabla(rutas))
    id_r = _input("ID de la ruta a eliminar")
    if _confirm(f"¿Eliminar ruta '{id_r}'?"):
        svc.eliminar_ruta(id_r)
        print(fmt.fmt_ok(f"Ruta '{id_r}' eliminada."))
    else:
        print("  Operación cancelada.")
    _pause()


def _cu13_ver_ruta(svc: EcorouteService) -> None:
    _header("Ver datos de ruta")
    id_r = _input("ID de la ruta")
    ruta = svc.obtener_ruta(id_r)
    entregas = svc.obtener_entregas_de_ruta(id_r)
    print(fmt.fmt_ruta(ruta))
    print("\n  Entregas asignadas:")
    print(fmt.fmt_entregas_tabla(entregas))
    _pause()


def _cu14_listar_rutas(svc: EcorouteService) -> None:
    pagina = 1
    while True:
        _header("Listado de rutas")
        rutas, total = svc.listar_rutas(pagina=pagina, por_pagina=PAGE_SIZE)
        total_paginas = max(1, math.ceil(total / PAGE_SIZE))
        print(fmt.fmt_rutas_tabla(rutas))
        print(fmt.fmt_pagination(pagina, total_paginas, total))
        print("\n  [N] Siguiente  [A] Anterior  [0] Volver")
        nav = _input("Opción").upper()
        if nav == "N" and pagina < total_paginas:
            pagina += 1
        elif nav == "A" and pagina > 1:
            pagina -= 1
        elif nav == "0":
            break


def _cu15_editar_ruta(svc: EcorouteService) -> None:
    _header("Editar ruta")
    rutas, _ = svc.listar_rutas(pagina=1, por_pagina=100)
    print(fmt.fmt_rutas_tabla(rutas))
    id_r = _input("ID de la ruta a editar")
    ruta = svc.obtener_ruta(id_r)
    entregas_actuales = svc.obtener_entregas_de_ruta(id_r)
    print(fmt.fmt_ruta(ruta))
    print("\n  Entregas actuales:")
    print(fmt.fmt_entregas_tabla(entregas_actuales))

    nuevo_vehiculo = None
    if _confirm("¿Cambiar el vehículo asignado?"):
        vehiculos = svc.listar_vehiculos_disponibles()
        print(fmt.fmt_vehiculos_tabla(vehiculos))
        nuevo_vehiculo = _input("ID del nuevo vehículo") or None

    nuevas_entregas = None
    if _confirm("¿Cambiar las entregas asignadas?"):
        disponibles = svc.listar_entregas_disponibles()
        print(fmt.fmt_entregas_tabla(disponibles))
        ids_raw = _input("IDs de entregas separados por coma")
        nuevas_entregas = [x.strip() for x in ids_raw.split(",") if x.strip()]

    actualizada = svc.editar_ruta(id_r, nuevo_vehiculo, nuevas_entregas)
    print(fmt.fmt_ok("Ruta actualizada."))
    print(fmt.fmt_ruta(actualizada))
    _pause()
